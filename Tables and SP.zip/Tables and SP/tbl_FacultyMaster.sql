USE [DevelopmentDB]
GO

/****** Object:  Table [dbo].[tbl_FacultyMaster]    Script Date: 27-02-2023 9.42.03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_FacultyMaster](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[CourseId] [int] NOT NULL,
	[MobileNo] [varchar](20) NOT NULL,
	[EmailAddress] [varchar](100) NOT NULL,
	[YOE] [int] NOT NULL,
	[status] [bit] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[transdate] [datetime] NOT NULL,
 CONSTRAINT [PK_tbl_FacultyMaster] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tbl_FacultyMaster] ADD  CONSTRAINT [DEFAULT_tbl_FacultyMaster_YOE]  DEFAULT ((0)) FOR [YOE]
GO

ALTER TABLE [dbo].[tbl_FacultyMaster]  WITH CHECK ADD  CONSTRAINT [FK_tbl_FacultyMaster] FOREIGN KEY([CourseId])
REFERENCES [dbo].[tbl_CourseMaster] ([id])
GO

ALTER TABLE [dbo].[tbl_FacultyMaster] CHECK CONSTRAINT [FK_tbl_FacultyMaster]
GO

