USE [DevelopmentDB]
GO

/****** Object:  StoredProcedure [dbo].[SendEmail]    Script Date: 27-02-2023 9.47.08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SendEmail]
    @ToEmail varchar(255),
    @Subject varchar(255),
    @Body varchar(max)
AS
BEGIN
    SET NOCOUNT ON;

    EXEC msdb.dbo.sp_send_dbmail
        @profile_name = 'ResetPassword',
        @recipients = @ToEmail,
        @subject = @Subject,
        @body = @Body,
        @body_format = 'HTML';
END
GO

