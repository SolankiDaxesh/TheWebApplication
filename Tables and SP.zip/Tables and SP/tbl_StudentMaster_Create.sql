USE [DevelopmentDB]
GO

/****** Object:  Table [dbo].[tbl_StudentMaster]    Script Date: 27-02-2023 9.33.57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_StudentMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[EnrollmentID] [varchar](20) NOT NULL,
	[Name] [varchar](255) NOT NULL,
	[Password] [varchar](255) NOT NULL,
	[personalEmail] [varchar](255) NOT NULL,
	[PhoneNumber] [varchar](15) NOT NULL,
	[StartDate] [date] NOT NULL,
	[CourseId] [int] NOT NULL,
	[Division] [varchar](255) NOT NULL,
	[CurrentSemester] [int] NOT NULL,
	[CurrentYear] [int] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[Cstatus] [bit] NOT NULL,
	[Transdate] [datetime] NOT NULL,
 CONSTRAINT [PK_tbl_StudentMaster] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

