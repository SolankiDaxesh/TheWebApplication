USE [DevelopmentDB]
GO

/****** Object:  StoredProcedure [dbo].[USP_AccountManagment]    Script Date: 27-02-2023 9.46.37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[USP_AccountManagment]

@Action int = 0,
  @message varchar(50) OUTPUT,
-- @userName varchar(100) =NULL,
-- @Email varchar(100) =NULL,
-- @mobileNo varchar(15) =NULL,
@Enrollment VARCHAR(20) = NULL,
@password varchar(max)= NULL
-- @cPassword varchar(max)= NULL,
-- @IpAddress varchar(20) = NULL,
-- @status bit = 0
as
BEGIN 
--if @Action = 1 --For registration
	-- begin
	-- 	insert into userRegistration(userName, Email, mobileNo, [password], cPassword,[IpAddress],[status],transdate,IsDeleted) values(@userName, @Email, @mobileNo, HASHBYTES('SHA2_512',@password), HASHBYTES('SHA2_512',@cPassword),@IpAddress,1,GETDATE(),0)
	-- end		
if @Action = 1 --For login
begin
IF EXISTS(SELECT top 1 * from tbl_StudentMaster where EnrollmentID=@Enrollment and [Password]=@password)
BEGIN
    set @message ='Success'
END
ELSE
BEGIN
    set @message = 'Invalid user'
END
	--select top 1 userName, [password] from userRegistration where userName=@userName and [password] = HASHBYTES('SHA2_512',@password) and status = 1
end
if @Action = 2
begin
	select top 1 personalEmail from tbl_StudentMaster where EnrollmentID=@Enrollment 
	
end
END										 
										 
										 
										 
GO

